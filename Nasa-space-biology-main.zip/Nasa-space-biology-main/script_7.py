# Create additional CSS for the enhanced features
enhanced_css = """
/* Enhanced styles for backend integration features */

/* Connection Status */
.connection-status {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 8px;
    border-radius: var(--radius-base);
    font-size: var(--font-size-xs);
    font-weight: var(--font-weight-medium);
    border: 1px solid var(--color-border);
}

.connection-status.connected {
    background: rgba(34, 197, 94, 0.1);
    color: #22c55e;
    border-color: rgba(34, 197, 94, 0.3);
}

.connection-status.disconnected {
    background: rgba(239, 68, 68, 0.1);
    color: #ef4444;
    border-color: rgba(239, 68, 68, 0.3);
}

.status-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: currentColor;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

/* Loading States */
.loading-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: var(--space-32);
    min-height: 200px;
}

.loading-container .spinner {
    margin-bottom: var(--space-16);
}

/* Error States */
.error-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: var(--space-32);
    background: rgba(239, 68, 68, 0.1);
    border: 1px solid rgba(239, 68, 68, 0.3);
    border-radius: var(--radius-lg);
    color: #ef4444;
    text-align: center;
}

.error-container button {
    margin-top: var(--space-16);
}

/* No Results */
.no-results {
    text-align: center;
    padding: var(--space-32);
    color: var(--color-text-secondary);
    font-style: italic;
}

/* AI Analysis Results */
.analysis-results {
    margin-top: var(--space-16);
    padding: var(--space-16);
    background: rgba(59, 130, 246, 0.05);
    border-radius: var(--radius-base);
    border: 1px solid rgba(59, 130, 246, 0.1);
}

.analysis-metrics {
    display: flex;
    gap: var(--space-16);
    margin-bottom: var(--space-12);
    flex-wrap: wrap;
}

.metric {
    padding: var(--space-4) var(--space-8);
    background: var(--color-surface);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-xs);
    font-weight: var(--font-weight-medium);
    border: 1px solid var(--color-border);
}

.keywords {
    margin-top: var(--space-12);
}

.keyword-tag {
    display: inline-block;
    margin: var(--space-2) var(--space-4) var(--space-2) 0;
    padding: var(--space-2) var(--space-6);
    background: linear-gradient(90deg, rgba(124,58,237,0.1), rgba(59,130,246,0.1));
    border: 1px solid rgba(124,58,237,0.2);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-xs);
    color: var(--color-primary);
}

/* AI Insights */
.ai-insights {
    margin-top: var(--space-16);
    padding: var(--space-16);
    background: linear-gradient(135deg, rgba(124,58,237,0.05), rgba(236,72,153,0.05));
    border-radius: var(--radius-base);
    border: 1px solid rgba(124,58,237,0.1);
}

.ai-insights h4 {
    margin: 0 0 var(--space-12) 0;
    color: var(--color-text);
    font-size: var(--font-size-base);
}

.insight-item {
    display: flex;
    align-items: flex-start;
    gap: var(--space-8);
    padding: var(--space-8) 0;
    border-bottom: 1px solid rgba(255,255,255,0.05);
}

.insight-item:last-child {
    border-bottom: none;
}

.insight-confidence {
    flex-shrink: 0;
    padding: var(--space-2) var(--space-6);
    background: rgba(34, 197, 94, 0.15);
    color: #22c55e;
    border-radius: var(--radius-sm);
    font-size: var(--font-size-xs);
    font-weight: var(--font-weight-medium);
}

/* AI Indicators on Cards */
.ai-indicators {
    display: flex;
    gap: var(--space-8);
    margin: var(--space-12) 0;
    flex-wrap: wrap;
}

.ai-indicator {
    display: flex;
    align-items: center;
    gap: var(--space-4);
    padding: var(--space-4) var(--space-8);
    background: linear-gradient(90deg, rgba(59,130,246,0.08), rgba(124,58,237,0.05));
    border: 1px solid rgba(59,130,246,0.15);
    border-radius: var(--radius-sm);
    font-size: var(--font-size-xs);
}

.indicator-label {
    color: var(--color-text-secondary);
    font-weight: var(--font-weight-medium);
}

.indicator-value {
    color: var(--color-primary);
    font-weight: var(--font-weight-semibold);
}

/* Real-time Data */
.realtime-data {
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-lg);
    padding: var(--space-20);
    margin-bottom: var(--space-20);
}

.realtime-data h3 {
    margin: 0 0 var(--space-16) 0;
    color: var(--color-text);
}

.data-metrics {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--space-12);
    margin-bottom: var(--space-16);
}

.metric-label {
    display: block;
    font-size: var(--font-size-xs);
    color: var(--color-text-secondary);
    margin-bottom: var(--space-2);
}

.metric-value {
    display: block;
    font-size: var(--font-size-lg);
    font-weight: var(--font-weight-semibold);
    color: var(--color-primary);
}

.latest-measurement {
    padding: var(--space-12);
    background: rgba(59,130,246,0.05);
    border: 1px solid rgba(59,130,246,0.1);
    border-radius: var(--radius-base);
}

.latest-measurement h4 {
    margin: 0 0 var(--space-8) 0;
    font-size: var(--font-size-sm);
    color: var(--color-text-secondary);
}

/* Enhanced Modal */
.ai-analysis-section, 
.data-points-section {
    margin-top: var(--space-20);
    padding-top: var(--space-20);
    border-top: 1px solid var(--color-border);
}

.ai-analysis-section h3, 
.data-points-section h3 {
    margin: 0 0 var(--space-16) 0;
    color: var(--color-text);
    display: flex;
    align-items: center;
    gap: var(--space-8);
}

.prediction-metrics {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--space-16);
    margin-bottom: var(--space-16);
    padding: var(--space-16);
    background: linear-gradient(135deg, rgba(59,130,246,0.05), rgba(124,58,237,0.05));
    border-radius: var(--radius-base);
    border: 1px solid rgba(59,130,246,0.1);
}

.prediction-metrics .metric {
    padding: 0;
    background: none;
    border: none;
    text-align: center;
}

.prediction-metrics .metric-label {
    font-size: var(--font-size-xs);
    color: var(--color-text-secondary);
}

.prediction-metrics .metric-value {
    font-size: var(--font-size-xl);
    font-weight: var(--font-weight-bold);
    color: var(--color-primary);
}

.risk-factors, .recommendations {
    margin-top: var(--space-16);
}

.risk-factors ul, .recommendations ul {
    margin: var(--space-8) 0 0 0;
    padding-left: var(--space-20);
}

.risk-factors li, .recommendations li {
    margin-bottom: var(--space-4);
    font-size: var(--font-size-sm);
    line-height: 1.4;
}

.risk-factors strong, .recommendations strong {
    color: var(--color-text);
    font-size: var(--font-size-sm);
    font-weight: var(--font-weight-semibold);
}

/* Data Points Summary */
.data-points-summary {
    display: grid;
    gap: var(--space-8);
    padding: var(--space-16);
    background: var(--color-surface);
    border-radius: var(--radius-base);
    border: 1px solid var(--color-border);
}

.data-point {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: var(--space-8) 0;
    border-bottom: 1px solid var(--color-border);
}

.data-point:last-child {
    border-bottom: none;
}

.data-type {
    font-size: var(--font-size-sm);
    color: var(--color-text-secondary);
    font-weight: var(--font-weight-medium);
}

.data-value {
    font-size: var(--font-size-sm);
    color: var(--color-text);
    font-weight: var(--font-weight-semibold);
    font-family: var(--font-family-mono);
}

/* Search Suggestions Enhancement */
.suggestions {
    max-height: 300px;
    overflow-y: auto;
    z-index: 100;
}

.suggestion-item {
    transition: background var(--duration-fast);
    border-bottom: 1px solid rgba(255,255,255,0.02);
}

.suggestion-item:hover {
    background: rgba(59,130,246,0.08);
    border-left: 3px solid var(--color-primary);
}

.suggestion-meta {
    opacity: 0.7;
    font-family: var(--font-family-mono);
}

/* Filter Enhancement */
.filter-group {
    position: relative;
}

.filter-select:focus {
    border-color: var(--color-primary);
    box-shadow: 0 0 0 3px rgba(59,130,246,0.1);
    outline: none;
}

/* Tab Enhancement */
.tab {
    position: relative;
    overflow: hidden;
}

.tab::before {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    width: 0;
    height: 2px;
    background: linear-gradient(90deg, var(--accent-6), var(--accent-2));
    transition: all var(--duration-normal);
    transform: translateX(-50%);
}

.tab.active::before {
    width: 100%;
}

.tab:hover::before {
    width: 60%;
}

/* Responsive Enhancements */
@media (max-width: 768px) {
    .analysis-metrics {
        flex-direction: column;
        gap: var(--space-8);
    }
    
    .prediction-metrics {
        grid-template-columns: 1fr;
    }
    
    .data-metrics {
        grid-template-columns: 1fr;
    }
    
    .ai-indicators {
        flex-direction: column;
    }
    
    .connection-status {
        display: none;
    }
}

/* Loading Animation Enhancement */
.spinner {
    animation: spin 1s linear infinite, pulse-glow 2s ease-in-out infinite;
}

@keyframes pulse-glow {
    0%, 100% {
        box-shadow: 0 0 5px rgba(59,130,246,0.3);
    }
    50% {
        box-shadow: 0 0 20px rgba(59,130,246,0.6), 0 0 30px rgba(124,58,237,0.4);
    }
}

/* Success/Error States */
.success-message {
    padding: var(--space-12) var(--space-16);
    background: rgba(34, 197, 94, 0.1);
    border: 1px solid rgba(34, 197, 94, 0.3);
    border-radius: var(--radius-base);
    color: #22c55e;
    font-size: var(--font-size-sm);
    margin: var(--space-12) 0;
}

.error-message {
    padding: var(--space-12) var(--space-16);
    background: rgba(239, 68, 68, 0.1);
    border: 1px solid rgba(239, 68, 68, 0.3);
    border-radius: var(--radius-base);
    color: #ef4444;
    font-size: var(--font-size-sm);
    margin: var(--space-12) 0;
}

/* Accessibility Enhancements */
.sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border: 0;
}

/* Focus Improvements */
.experiment-card:focus-visible {
    outline: 2px solid var(--color-primary);
    outline-offset: 2px;
}

.suggestion-item:focus-visible {
    background: rgba(59,130,246,0.1);
    outline: 2px solid var(--color-primary);
    outline-offset: -2px;
}

/* High Contrast Mode Support */
@media (prefers-contrast: high) {
    .ai-indicator,
    .analysis-results,
    .ai-insights {
        border-width: 2px;
    }
    
    .connection-status {
        border-width: 2px;
    }
    
    .keyword-tag {
        border-width: 2px;
    }
}

/* Reduced Motion Support */
@media (prefers-reduced-motion: reduce) {
    .spinner {
        animation: none;
    }
    
    .status-dot {
        animation: none;
    }
    
    .tab::before {
        transition: none;
    }
    
    .experiment-card {
        transition: none;
    }
}
"""

# Append to the existing style.css
with open("enhanced_styles.css", "w") as f:
    f.write(enhanced_css)

print("✅ Enhanced styles created for backend integration features")